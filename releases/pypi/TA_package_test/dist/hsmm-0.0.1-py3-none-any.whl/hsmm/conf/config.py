import sys
import json

##################
##Debug Variable##
global dbg
dbg = True
sys.stdout.reconfigure(encoding='utf-8')
#hunter.trace(module="__main__")
##################

##################
###ENV Variables##
global items_file
global levels_file
global effects_file
global entity_file
items_file = "items.json"
levels_file = "levels.json"
effects_file = "effects.json"
entity_file = "entities.json"
##################